
1. Place the coding in below path 
c:\xampp\htdocs\projects\medical_card\web

2. Opent  localhost/phpmyadmin
   Crete DB - medical_card
   
3. Import medical_card.sql 

4. For Project run the path in browser

localhost/projects/medical_card/web/

Hospital
hospital@gmail.com
test

User
user@gmail.com
test